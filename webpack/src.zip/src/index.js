window.$ = window.jQuery

require('./scss/main.scss')
require('./js/main.js')